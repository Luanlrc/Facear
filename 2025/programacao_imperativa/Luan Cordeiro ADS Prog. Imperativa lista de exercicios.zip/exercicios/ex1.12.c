#include <stdio.h>

void main(void){
    const int num = 500;
    printf("O valor da constante definida e %i", num);
}