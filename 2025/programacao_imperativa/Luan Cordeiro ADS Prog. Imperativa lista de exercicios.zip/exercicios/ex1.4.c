#include <stdio.h>

void main (void){
    int num;
    printf("Digite um numero inteiro: \n");
    scanf("%i", &num);

    printf("O numero digitado e %f", num);
}