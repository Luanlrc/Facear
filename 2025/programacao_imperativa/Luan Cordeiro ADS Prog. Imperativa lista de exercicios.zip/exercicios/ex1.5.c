#include <stdio.h>

void main (void){
    float num;
    printf("Digite um numero inteiro: \n");
    scanf("%f", &num);

    printf("O numero digitado e %d", num);
}