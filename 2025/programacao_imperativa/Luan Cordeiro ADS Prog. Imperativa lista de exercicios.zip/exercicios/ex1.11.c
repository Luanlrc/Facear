#include <stdio.h>

#define var 5.546f

void main(void){
    printf("O valor da constante definida e %f", var);
}