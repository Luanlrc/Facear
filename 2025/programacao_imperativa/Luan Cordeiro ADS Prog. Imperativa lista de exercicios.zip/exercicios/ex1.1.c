#include <stdio.h>

void main(void){
    printf("Inicio do programa\n");
    printf("Fim");
}